local Rayfield = loadstring(game:HttpGet('https://sirius.menu/rayfield'))()

local Window = Rayfield:CreateWindow({
   Name = "nogada hub",
   Icon = 0,
   LoadingTitle = "loading",
   LoadingSubtitle = "by babu,root_lua",
   Theme = "AmberGlow",
   ToggleUIKeybind = "K",
   Discord = { Enabled = false, Invite = "noinvitelink", RememberJoins = true },
})

local Tab = Window:CreateTab("메인")

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local RS = game:GetService("ReplicatedStorage")
local player = Players.LocalPlayer

-- [ 안티치트 필수 설정값 ]
local RECORD_INTERVAL = 0.07
local CHECK_POSITION = Vector3.new(-76, 6, -69)
local CHECK_RADIUS = 10
local FORCE_TP_TIME = 1
local FORCE_TP_POSITION = Vector3.new(-75, 0, 12)

-- [ 상태 관리 변수 ]
local isEnabled = false
local lastSafeCFrame = CFrame.new()
local lastRecordTime = 0
local stayTimer = 0
local infJumpEnabled = false
local tpWalkEnabled = false
local tpWalkSpeed = 0
local savePosEnabled = false
local isTweening = false
local lastGroundedCFrame = nil
local debounce = false

local function getCharacterData()
    local char = player.Character or player.CharacterAdded:Wait()
    local hrp = char:WaitForChild("HumanoidRootPart", 5)
    local hum = char:WaitForChild("Humanoid", 5)
    return char, hrp, hum
end

---
-- [ 1. 안티치트 바이패스 (원본 로직 복구) ]
---
Tab:CreateToggle({
   Name = "안티치트 바이패스(베타)",
   CurrentValue = false,
   Flag = "TeleportToggle", 
   Callback = function(Value)
      isEnabled = Value
      if isEnabled then
          task.spawn(function()
              local char, hrp, hum = getCharacterData()
              if hum and hrp then
                  -- 첫 번째 사망
                  hum.Health = 0
                  task.wait(1)
                  -- 2초간 랜덤 속도 부여 (바이패스 핵심)
                  local startTime = tick()
                  while tick() - startTime < 2 do
                      if hrp then 
                          hrp.Velocity = Vector3.new(math.random(-50, 50), 20, math.random(-50, 50)) 
                      end
                      task.wait(0.1)
                  end
                  -- 두 번째 사망 및 알림
                  local _, _, newHum = getCharacterData()
                  if newHum then 
                      newHum.Health = 0 
                      Rayfield:Notify({
                          Title = "시스템",
                          Content = "안돼면 재설정 해주세요",
                          Duration = 2,
                      })
                  end
              end
          end)
      else
          stayTimer = 0
      end
   end,
})

Tab:CreateSection("재자리로 다시 돌아온다면 껐다가 다시 켜주세요")

---
-- [ 2. 낙사 방지 (Y+9 및 트윈) ]
---
local function CreateSafetyZone(target)
    local name = "Kill_Safety_Layer"
    local old = workspace:FindFirstChild(name)
    if old then old:Destroy() end

    local safety = Instance.new("Part")
    safety.Name = name
    safety.Size = Vector3.new(target.Size.X, 5, target.Size.Z) -- 높이 5로 확장
    safety.CFrame = target.CFrame * CFrame.new(0, 9, 0) -- Y+9 위
    
    safety.Anchored = true
    safety.CanCollide = false 
    safety.Color = Color3.fromRGB(255, 0, 0)
    safety.Transparency = 0.7
    safety.Material = Enum.Material.Neon
    safety.Parent = workspace

    safety.Touched:Connect(function(hit)
        if not savePosEnabled or isTweening or debounce then return end
        if hit.Parent == player.Character and lastGroundedCFrame then
            local hrp = hit.Parent:FindFirstChild("HumanoidRootPart")
            if hrp then
                isTweening, debounce = true, true
                hrp.Anchored = true
                hrp.Velocity = Vector3.new(0,0,0)
                local tInfo = TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
                local tween = TweenService:Create(hrp, tInfo, {CFrame = lastGroundedCFrame})
                tween:Play()
                tween.Completed:Connect(function()
                    hrp.Anchored = false
                    isTweening = false
                    task.wait(0.5)
                    debounce = false
                end)
            end
        end
    end)
end

Tab:CreateToggle({
   Name = "낙사 방지",
   CurrentValue = false,
   Flag = "AntiFallTween",
   Callback = function(Value)
      savePosEnabled = Value
      if savePosEnabled then
          local target = workspace:FindFirstChild("Kill")
          if target then
              CreateSafetyZone(target)
              task.spawn(function()
                  while savePosEnabled do
                      local ti = target:FindFirstChildOfClass("TouchTransmitter")
                      if ti then ti:Destroy() end
                      task.wait(0.1)
                  end
              end)
          end
      else
          local safety = workspace:FindFirstChild("Kill_Safety_Layer")
          if safety then safety:Destroy() end
          debounce = false
      end
   end,
})

---
-- [ 3. 기타 기능 ]
---
Tab:CreateToggle({
   Name = "무한 점프",
   CurrentValue = false,
   Flag = "InfJump", 
   Callback = function(Value) infJumpEnabled = Value end,
})

UserInputService.JumpRequest:Connect(function()
    if infJumpEnabled then
        local _, _, hum = getCharacterData()
        if hum then hum:ChangeState(Enum.HumanoidStateType.Jumping) end
    end
end)

Tab:CreateToggle({
   Name = "TPWalk 활성화",
   CurrentValue = false,
   Flag = "TPWalkToggle",
   Callback = function(Value) tpWalkEnabled = Value end,
})

Tab:CreateSlider({
   Name = "TPWalk 속도",
   Range = {0, 6},
   Increment = 0.001,
   Suffix = "Speed",
   CurrentValue = 0,
   Flag = "TPWalkSlider",
   Callback = function(Value) tpWalkSpeed = Value end,
})

---
-- [ 4. 자동 퀘스트 & 텔레포트 ]
---
local autoQuestEnabled = false
Tab:CreateToggle({
   Name = "자동 퀘스트 & 텔레포트",
   CurrentValue = false,
   Flag = "AutoQuestTP",
   Callback = function(Value)
      autoQuestEnabled = Value
      if autoQuestEnabled then
          local _, hrp = getCharacterData()
          if hrp then hrp.CFrame = CFrame.new(-132, 1, 222) end

          task.spawn(function()
              local bus = workspace:FindFirstChild("Bus")
              if bus then
                  for _, v in ipairs(bus:GetChildren()) do
                      if v:IsA("BasePart") then v:Destroy() end
                  end
              end
          end)

          task.spawn(function()
              local acceptTick, completeTick = 0, 0
              local targets = { Phone = true, Wallet = true, Creditcard = true }
              while autoQuestEnabled do
                  local now = tick()
                  for _, v in ipairs(workspace:GetDescendants()) do
                      if v:IsA("ProximityPrompt") then
                          v.HoldDuration = 0
                          if v.Parent and targets[v.Parent.Name] then
                              v.RequiresLineOfSight = false
                              v.MaxActivationDistance = 999
                              fireproximityprompt(v)
                          end
                      end
                  end
                  if now - acceptTick >= 0.5 then
                      if RS:FindFirstChild("HomelessQuestRemotes_NEW") then
                          RS.HomelessQuestRemotes_NEW.AcceptQuest:FireServer()
                      end
                      acceptTick = now
                  end
                  if now - completeTick >= 0.2 then
                      if RS:FindFirstChild("HomelessQuestRemotes_NEW") then
                          RS.HomelessQuestRemotes_NEW.CompleteQuest:FireServer()
                      end
                      completeTick = now
                  end
                  task.wait(0.3)
              end
          end)
      end
   end,
})

---
-- [ 5. 메인 시스템 루프 ]
---
RunService.Heartbeat:Connect(function()
    if savePosEnabled and not isTweening and not debounce then
        local _, hrp, hum = getCharacterData()
        if hrp and hum and hum.FloorMaterial ~= Enum.Material.Air then
            lastGroundedCFrame = hrp.CFrame + Vector3.new(0, 0.5, 0)
        end
    end

    if tpWalkEnabled then
        local _, hrp, hum = getCharacterData()
        if hrp and hum and hum.MoveDirection.Magnitude > 0 then
            hrp.CFrame = hrp.CFrame + (hum.MoveDirection * (tpWalkSpeed / 10))
        end
    end
end)

RunService.RenderStepped:Connect(function(deltaTime)
    if not isEnabled then return end
    local _, hrp = getCharacterData()
    if not hrp then return end
    
    local now = tick()
    local distance = (hrp.Position - CHECK_POSITION).Magnitude

    -- 실시간 위치 기록
    if now - lastRecordTime >= RECORD_INTERVAL then
        lastRecordTime = now
        lastSafeCFrame = hrp.CFrame
    end

    -- 감지 범위 내에 있으면 위치 고정 (안티치트 핵심)
    if distance <= CHECK_RADIUS then
        stayTimer = stayTimer + deltaTime
        if stayTimer >= FORCE_TP_TIME then
            hrp.CFrame = CFrame.new(FORCE_TP_POSITION)
            stayTimer = 0
        else
            if lastSafeCFrame then hrp.CFrame = lastSafeCFrame end
        end
    else
        stayTimer = 0
    end
end)