import discord
from discord.ext import commands
import asyncio
import random
import requests
import os
import mss
import io
import sys
import pyautogui
import logging
from PIL import Image
from datetime import datetime, timedelta, timezone
from colorama import init, Fore, Style
from tkinter import filedialog, Tk, simpledialog

init(autoreset=True)


TOKEN_PATH = os.path.join(os.environ['LOCALAPPDATA'], 'discord_my_token.txt')

class ColoredFormatter(logging.Formatter):
    def format(self, record):
        timestamp = datetime.fromtimestamp(record.created).strftime('%H:%M:%S')
        if record.levelno >= logging.WARNING:
            return f"{Fore.YELLOW}[{timestamp}] [WARN] {record.name}: {record.msg}{Style.RESET_ALL}"
        return f"[{timestamp}] [{record.levelname}] {record.name}: {record.msg}"

discord_logger = logging.getLogger('discord')
discord_logger.setLevel(logging.WARNING)
handler = logging.StreamHandler()
handler.setFormatter(ColoredFormatter())
discord_logger.addHandler(handler)
discord_logger.propagate = False

def get_time(): return datetime.now().strftime("%H:%M:%S")
def log_success(msg): print(f"{Fore.GREEN}[{get_time()}] [SUCCESS] {msg}")
def log_info(msg): print(f"{Fore.CYAN}[{get_time()}] [INFO] {msg}")
def log_warn(msg): print(f"{Fore.YELLOW}[{get_time()}] [WARN] {msg}")
def log_error(msg): print(f"{Fore.RED}[{get_time()}] [ERROR] {msg}")
def log_cmd(ctx): 
    channel_name = getattr(ctx.channel, 'name', 'DM/Group')
    print(f"{Fore.MAGENTA}[{get_time()}] [COMMAND] {Fore.WHITE}{ctx.message.content} {Fore.BLACK}{Style.BRIGHT}(Channel: {channel_name})")


def get_or_set_token():
    if os.path.exists(TOKEN_PATH):
        with open(TOKEN_PATH, 'r', encoding='utf-8') as f:
            token = f.read().strip()
            if token:
                log_success(f"토큰 로드 완료: {TOKEN_PATH}")
                return token

    root = Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    token = simpledialog.askstring("Token Input", "디스코드 토큰을 입력하십시오:", parent=root)
    root.destroy()
    
    if not token:
        return None
        
    with open(TOKEN_PATH, 'w', encoding='utf-8') as f:
        f.write(token)
    log_success("토큰이 저장되었습니다.")
    return token

current_prefix = "!"
vaporize_mode = False
is_spamming = False
emoji_mode = False
logging_target_id = None 
log_file_path = ""
BASE_LOG_DIR = ""

client = commands.Bot(command_prefix=lambda b, m: current_prefix, self_bot=True, help_command=None)

@client.event
async def on_ready():
    global BASE_LOG_DIR
    if sys.platform == "win32":
        os.system("title Discord Self-Bot [Active]")
        os.system("color 0A")
    os.system('cls' if os.name == 'nt' else 'clear')
    
    

    print(f"{Fore.GREEN}{'='*50}")
    print(f"{Fore.GREEN}   SYSTEM ONLINE: {client.user.name}")
    print(f"{Fore.GREEN}   STATUS: CONNECTED")
    print(f"{Fore.GREEN}{'='*50}")
    
    desktop = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
    log_info("로그 저장 경로를 선택하십시오.")
    root = Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    selected = filedialog.askdirectory(title="로그 저장 경로 선택", initialdir=desktop)
    root.destroy()
    
    if not selected or "system32" in selected.lower():
        BASE_LOG_DIR = desktop
        log_warn("경로 미선택으로 인해 바탕화면에 저장됩니다.")
    else:
        BASE_LOG_DIR = selected
    log_success(f"경로 확정: {BASE_LOG_DIR}")

    log_warn("BRO가 만들었어 BRO는 ROOT_LUA야 근데 이거 오픈소스라고 배껴가면 안대 이거 MIT라이선스 걸려있다구웃 ") 


@client.command()
async def 명령어(ctx):
    log_cmd(ctx)
    p = current_prefix
    help_text = (
        f"👑 **[ DISCORD SELF-BOT SYSTEM ]** 👑\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"🚀 **Main Management**\n"
        f"〉 `{p}도배 [내용]` : 3명 랜덤 멘션 도배 (1초 간격)\n"
        f"〉 `{p}중지` : 모든 도배 및 작업 즉시 중단\n"
        f"〉 `{p}취소` : 최근 10분 내 본인 메시지 일괄 삭제\n"
        f"〉 `{p}프리픽스 [기호]` : 명령어 접두사 변경\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"🛰 **Special Operations**\n"
        f"〉 `{p}로깅` : **[은밀]** 흔적 없이 채팅 실시간 기록\n"
        f"〉 `{p}스샷` : 현재 PC 전체 화면 캡처 전송\n"
        f"〉 `{p}모두멘션` : 서버 전체 인원 태그 호출\n"
        f"〉 `{p}체크 [토큰]` : 외부 토큰 유효성 정밀 검사\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"🎭 **Mode Settings**\n"
        f"〉 `{p}증발모드` : (토글) 메시지 5초 후 자동 삭제\n"
        f"〉 `{p}이모지모드` : (토글) 메시지 끝 🔥 자동 부착\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"⚠️ **System Control**\n"
        f"〉 `{p}서비스 중지` : 셀프봇 프로세스 완전 종료\n"
        f"〉 `{p}컴터 끄기` : 시스템 즉시 셧다운 수행\n"
        f"━━━━━━━━━━━━━━━━━━━━━"
    )
    await ctx.send(help_text)


@client.command()
async def 도배(ctx, *, message):
    log_cmd(ctx)
    global is_spamming
    if is_spamming: return
    is_spamming = True
    members = [m.mention for m in ctx.guild.members if not m.bot] if ctx.guild else []
    while is_spamming:
        try:
            targets = random.sample(members, min(len(members), 3)) if members else []
            mention_str = " ".join(targets) + " " if targets else ""
            await ctx.send(f"{mention_str}{message} [{random.randint(1000, 9999)}]")
            await asyncio.sleep(1.0)
        except: break
    is_spamming = False

@client.command()
async def 로깅(ctx):
    log_cmd(ctx)
    global logging_target_id, log_file_path
    try: await ctx.message.delete()
    except: pass
    if logging_target_id == ctx.channel.id:
        logging_target_id = None
        log_warn("로깅 종료.")
    else:
        logging_target_id = ctx.channel.id
        safe_name = "".join([c for c in str(ctx.channel) if c.isalnum() or c in (' ', '_')]).strip()
        log_file_path = os.path.join(BASE_LOG_DIR, f"log_{safe_name}_{datetime.now().strftime('%m%d_%H%M')}.txt")
        with open(log_file_path, "w", encoding="utf-8") as f:
            f.write(f"--- LOG START: {datetime.now()} ---\n")
        log_success(f"로깅 시작: {log_file_path}")

@client.command()
async def 취소(ctx):
    log_cmd(ctx)
    limit = datetime.now(timezone.utc) - timedelta(minutes=10)
    count = 0
    async for msg in ctx.channel.history(limit=50):
        if msg.created_at < limit: break
        if msg.author == client.user:
            try:
                await msg.delete()
                count += 1
                await asyncio.sleep(1.0)
            except: continue
    log_success(f"{count}개 삭제 완료.")

@client.command()
async def 증발모드(ctx, status: str = None):
    log_cmd(ctx)
    global vaporize_mode
    vaporize_mode = not vaporize_mode if status is None else status.upper() == "ON"
    await ctx.send(f"💥 증발 모드: {'ON' if vaporize_mode else 'OFF'}", delete_after=3)

@client.command()
async def 이모지모드(ctx, status: str = None):
    log_cmd(ctx)
    global emoji_mode
    emoji_mode = not emoji_mode if status is None else status.upper() == "ON"
    await ctx.send(f"✨ 이모지 모드: {'ON' if emoji_mode else 'OFF'}", delete_after=3)

@client.command()
async def 스샷(ctx):
    log_cmd(ctx)
    with mss.mss() as sct:
        for i, mon in enumerate(sct.monitors[1:], 1):
            img_data = sct.grab(mon)
            img = Image.frombytes("RGB", img_data.size, img_data.bgra, "raw", "BGRX")
            with io.BytesIO() as buf:
                img.save(buf, 'PNG'); buf.seek(0)
                await ctx.send(f"🖥️ 디스플레이 {i}", file=discord.File(buf, f'mon{i}.png'))

@client.command()
async def 모두멘션(ctx):
    log_cmd(ctx)
    if not ctx.guild: return
    mentions = [m.mention for m in ctx.guild.members if not m.bot]
    for i in range(0, len(mentions), 10):
        await ctx.send(" ".join(mentions[i:i+10]))
        await asyncio.sleep(1.2)

@client.command()
async def 체크(ctx, token: str):
    log_cmd(ctx)
    res = requests.get("https://discord.com/api/v9/users/@me", headers={"Authorization": token})
    if res.status_code == 200: await ctx.send(f"✅ 유효 토큰: `{res.json()['username']}`")
    else: await ctx.send("❌ 무효 토큰")

@client.command()
async def 중지(ctx):
    log_cmd(ctx)
    global is_spamming
    is_spamming = False
    await ctx.send("🛑 모든 작업 중단", delete_after=2)

@client.command()
async def 서비스(ctx, action):
    log_cmd(ctx)
    if action == "중지": await client.close()

@client.command()
async def 컴터(ctx, action):
    log_cmd(ctx)
    if action == "끄기": os.system("shutdown /s /t 0")

@client.command()
async def 프리픽스(ctx, new_prefix: str):
    log_cmd(ctx)
    global current_prefix
    current_prefix = new_prefix
    await ctx.send(f"✅ 프리픽스 변경: `{new_prefix}`")

@client.event
async def on_message(message):
    global logging_target_id, log_file_path, vaporize_mode, emoji_mode
    if logging_target_id == message.channel.id and not message.content.startswith(current_prefix):
        try:
            with open(log_file_path, "a", encoding="utf-8") as f:
                f.write(f"[{get_time()}] {message.author.name}: {message.content}\n")
        except: pass
    if message.author == client.user and not message.content.startswith(current_prefix):
        if vaporize_mode:
            async def d(m):
                await asyncio.sleep(5)
                try: await m.delete()
                except: pass
            asyncio.create_task(d(message))
        if emoji_mode:
            try: await message.edit(content=f"{message.content} 🔥")
            except: pass
    await client.process_commands(message)


if __name__ == "__main__":
    TOKEN = None
    try:
        TOKEN = get_or_set_token()
        if TOKEN:
            client.run(TOKEN)
        else:
            log_error("토큰이 입력되지 않았습니다.")
    except Exception as e:
        log_error(f"오류 발생: {e}")
        if "Improper token" in str(e):
            if os.path.exists(TOKEN_PATH): os.remove(TOKEN_PATH)
            log_warn("잘못된 토큰 정보가 삭제되었습니다.")
    finally:
        print(f"\n{Fore.YELLOW}="*50)
        input(f"{Fore.WHITE}프로그램이 종료되었습니다. [Enter] 키를 누르면 창이 닫힙니다...")